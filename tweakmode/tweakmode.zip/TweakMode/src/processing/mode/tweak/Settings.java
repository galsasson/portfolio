package processing.mode.tweak;

public class Settings {
	public static boolean alwaysShowColorBoxes = true;
}
