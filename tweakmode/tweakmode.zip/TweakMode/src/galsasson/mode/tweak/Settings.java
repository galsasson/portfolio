package galsasson.mode.tweak;

public class Settings {
	public static boolean alwaysShowColorBoxes = true;
}
